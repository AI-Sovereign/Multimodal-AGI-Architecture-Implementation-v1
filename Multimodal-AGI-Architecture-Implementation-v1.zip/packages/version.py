"""Project version number."""
__version__ = '0.1.0'
__author__ = 'Most Advanced AI Professional'
